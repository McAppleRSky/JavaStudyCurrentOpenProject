package org.example.lab1.calc;

import org.example.lab1.calc.operations.Cmd;
import org.example.lab1.calc.operations.CmdPlus;
import org.example.lab1.calc.operations.Precmd;
import org.reflections.Reflections;
import org.reflections.scanners.MethodAnnotationsScanner;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.scanners.TypeAnnotationsScanner;
import org.reflections.util.ClasspathHelper;
import org.reflections.util.ConfigurationBuilder;
import org.reflections.util.FilterBuilder;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.Set;

public class Cli {

/*    private static List<Class<?>> getAllClassesFrom(String packageName) {
        return new Reflections(packageName, new SubTypesScanner(false))
                .getAllTypes()
                .stream()
                .map(name -> {
                    try {
                        return Class.forName(name);
                    } catch (ClassNotFoundException e) {
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
*/

    private static Calc calc = new Calc();

    static String prefixPackage = "org.example.lab1.calc.operations";
    static Reflections reflections;
    static Set<Class<? extends Cmd>> list;
    //static Set<Class<? extends Cmd>> subTypes;
    //static Collection srcPath;
    //static URL classesURL;
    //static URLClassLoader classLoader
        //ClassLoader classLoader
        ;
    //static SubTypesScanner scanner;


    public static void main(String[] args) {

        //Set<Class<? extends org.example.lab1.calc.operations.Cmd>> list ;
//        calc.setOperationsList(list);

        list = new Reflections(prefixPackage).getSubTypesOf(Cmd.class);
        //Reflections
        //reflections = new Reflections(prefixPackage);

        //srcPath = ClasspathHelper.forPackage(prefixPackage);
//        try {classesURL = Paths.get("build/classes/java/main").toUri().toURL();} catch (MalformedURLException e) {e.printStackTrace();}
//        classLoader = URLClassLoader.newInstance(new URL[]{classesURL}, ClasspathHelper.staticClassLoader());

        //scanner = new SubTypesScanner(false);
//        ConfigurationBuilder cfg = new ConfigurationBuilder().setUrls(srcPath).setScanners(scanner);
//        reflections = new Reflections( cfg );

//        reflections = new Reflections(new ConfigurationBuilder()
//                .addUrls(ClasspathHelper.forPackage(prefixPackage, classLoader))
//                .addClassLoader(classLoader)
//                .filterInputsBy(new FilterBuilder().includePackage(prefixPackage))
//                .setScanners(
//                        new SubTypesScanner(false)
                        //,new TypeAnnotationsScanner()
                        //,new MethodAnnotationsScanner()
//                        ));
//        Set<Class<? extends Cmd>> verbs = reflections.getSubTypesOf(Cmd.class);


        //Set<Class<? extends org.example.lab1.calc.operations.Cmd>>
                //subTypes = reflections.getSubTypesOf(org.example.lab1.calc.operations.Cmd.class);
                                                ;

        System.out.println(calc.solve(args));
    }
}

// http://java-online.ru/java-reflection.xhtml
// reflections getSubTypesOf ClassNotFoundException
// https://o7planning.org/ru/10155/java-reflection-tutorial
// https://stackru.com/questions/10393368/google-app-engine-i-biblioteka-orgreflection-v-java-oshibka-vo-vremya-protseduryi-skanirovaniya