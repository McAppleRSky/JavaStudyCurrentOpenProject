package org.example.lab1.calc.pre;

public interface Precmd {
    final String allCmdInString = "+-*/";
    int getIntCmd(int i);

}
