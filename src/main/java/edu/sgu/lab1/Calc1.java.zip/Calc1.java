package org.example.lab1;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;

public class Calc1 {

    static HashMap<Integer, Integer> intValues = new HashMap<>();

    static Logger logger = LogManager.getLogger("Calc");

    public static void main(String[] args) {
        String IntOperInt = "ioi";
        try {
            tstArgs(args);
        }catch (Exception exception){
            exception.printStackTrace();
        }
        if( ! IntOperInt.equals(sigArgs(args))){
            logger.error("Can not solve expression");
        }else{
            System.out.println("nothing");
        }
    }

    static String sigArgs(String[] asigArgs){
        StringBuffer result = new StringBuffer("   ");
        for(int i=0;i<result.length();i++) {
            result.setCharAt(i, tstArg(i, asigArgs[i]));
        }
        return result.toString();
    }

    static void tstArgs(String[] tstStrs) throws Exception {
        if (tstStrs.length < 3)
            throw new Exception("Too many parameters");
        else if (tstStrs.length > 3)
            logger.warn("Too match parameters");
    }

    static char tstArg(int i, String arg) {
        try {
            intValues.put(i, Integer.parseInt(arg));
        }catch (NumberFormatException numberFormatException) {
            if (arg.charAt(0) == '+' || arg.charAt(0) == '-' || arg.charAt(0) == '*' || arg.charAt(0) == '/') {
                intValues.put(i, arg.codePointAt(0));
                return 'o';
            } else
                return 'n';
        }
        return 'i';
    }
    
}
