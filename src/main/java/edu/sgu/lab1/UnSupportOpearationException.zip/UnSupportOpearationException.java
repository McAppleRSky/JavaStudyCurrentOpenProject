package edu.sgu.lab1;

public class UnSupportOpearationException extends Throwable {
}
