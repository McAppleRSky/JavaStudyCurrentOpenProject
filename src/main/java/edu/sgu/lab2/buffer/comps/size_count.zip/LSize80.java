package edu.sgu.lab2.buffer.comps;

public interface LSize80 {
    int size = 80;
}