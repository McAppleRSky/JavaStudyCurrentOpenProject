package edu.sgu.lab2.buffer.comps;

public interface LSize90 {
    int size = 90;
}