package edu.sgu.lab2.buffer.comps;

public interface NBufCount6 {
    int count = 6;
}