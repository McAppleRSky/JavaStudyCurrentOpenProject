package edu.sgu.lab2.buffer.comps;

public interface NBufCount3 {
    int count = 3;
}