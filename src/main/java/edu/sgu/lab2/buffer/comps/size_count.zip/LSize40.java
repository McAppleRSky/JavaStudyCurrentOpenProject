package edu.sgu.lab2.buffer.comps;

public interface LSize40 {
    int size = 40;
}
