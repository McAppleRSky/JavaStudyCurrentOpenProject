package edu.sgu.lab2.buffer.comps;

public interface NBufCount7 {
    int count = 7;
}