package edu.sgu.lab2.buffer.comps;

public interface NBufCount4 {
    int count = 4;
}