package edu.sgu.lab2.buffer.comps;

public interface NBufCount5 {
    int count = 5;
}