package edu.sgu.lab2.buffer.comps;

public interface LSize70 {
    int size = 70;
}