package edu.sgu.lab2.buffer.comps;

public interface LSize50 {
    int size = 50;
}