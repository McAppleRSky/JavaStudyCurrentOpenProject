package edu.sgu.lab2.buffer.comps;

public interface LSize60 {
    int size = 60;
}